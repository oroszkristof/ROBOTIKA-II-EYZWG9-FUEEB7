#include <WiFi.h>
#include <WebServer.h>

// Wi-Fi beállítások
const char* ssid = "SAJAT_WIFI_NEVED";
const char* password = "SAJAT_WIFI_JELSZOVAD";

WebServer server(80);

// A 6 kulcs globális tömbjei
const int NUM_KEYS = 6;

// Cseréld ki a Wokwi bekötésednek megfelelő pontos GPIO pin-ekre!
const int KEY_PINS[NUM_KEYS] = {27, 26, 33, 32, 35, 34}; 
const int LED_PINS[NUM_KEYS] = {25, 14, 12, 13, 2, 4};   

bool keyStates[NUM_KEYS];
bool lastKeyStates[NUM_KEYS];
bool suspendedStates[NUM_KEYS];

String eventLog = "";

void logEvent(String event) {
  eventLog = "- " + event + "\n" + eventLog; 
  Serial.println(event);
}

// Dinamikus Webes kezelőfelület (HTML/CSS/JS)
const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kulcskezelő Rendszer - III. Fázis</title>
  <style>
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f4f7f6; color: #333; text-align: center; padding: 20px; }
    h1 { color: #2c3e50; font-size: 28px; margin-bottom: 30px; }
    #keys-container { display: flex; flex-wrap: wrap; justify-content: center; gap: 20px; }
    .card { background: white; width: 300px; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
    .card h2 { margin-top: 0; color: #34495e; font-size: 20px; }
    .status-box { padding: 10px; margin: 10px 0; border-radius: 5px; font-weight: bold; font-size: 14px; }
    .helyen { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .elveve { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    .felfuggesztve { background: #fff3cd; color: #856404; border: 1px solid #ffeeba; }
    button { border: none; padding: 8px 15px; color: white; border-radius: 5px; cursor: pointer; font-size: 14px; margin: 5px; transition: 0.3s; width: 45%; }
    .btn-suspend { background: #dc3545; }
    .btn-suspend:hover { background: #c82333; }
    .btn-activate { background: #28a745; }
    .btn-activate:hover { background: #218838; }
    .log-container { max-width: 900px; margin: 30px auto; }
    .log-box { background: #333; color: #0f0; text-align: left; padding: 15px; height: 200px; overflow-y: auto; font-family: monospace; font-size: 14px; border-radius: 5px; }
  </style>
</head>
<body>
  <h1>Kulcskezelő Rendszer (6 Kulcs)</h1>
  
  <div id="keys-container">
    <!-- A JavaScript fogja ide generálni a 6 kulcs kártyáját -->
  </div>

  <div class="log-container">
    <h3>Eseménynapló</h3>
    <div id="event-log" class="log-box">Betöltés...</div>
  </div>

  <script>
    setInterval(fetchStatus, 1000);

    function fetchStatus() {
      fetch('/api/status')
        .then(response => response.json())
        .then(data => {
          let html = '';
          
          // Végigiterálunk a 6 kulcs adatain
          data.keys.forEach((key, index) => {
            const physClass = key.physical === "HELYÉN" ? "helyen" : "elveve";
            const useClass = key.suspended ? "felfuggesztve" : "helyen";
            const useText = key.suspended ? "FELFÜGGESZTVE" : "AKTÍV";

            html += `
              <div class="card">
                <h2>${index + 1}. Kulcs</h2>
                <div class="status-box ${physClass}">Fizikai: ${key.physical}</div>
                <div class="status-box ${useClass}">Használat: ${useText}</div>
                <button class="btn-suspend" onclick="toggleState('suspend', ${index})">Felfüggeszt</button>
                <button class="btn-activate" onclick="toggleState('activate', ${index})">Aktivál</button>
              </div>
            `;
          });

          document.getElementById('keys-container').innerHTML = html;
          document.getElementById('event-log').innerText = data.log;
        });
    }

    function toggleState(action, id) {
      // API hívás a kiválasztott kulcs ID-jével (0-5)
      fetch('/api/' + action + '?id=' + id, { method: 'POST' }).then(() => fetchStatus());
    }
    
    fetchStatus();
  </script>
</body>
</html>
)rawliteral";

void setup() {
  Serial.begin(115200);
  
  // A 6 kulcs és LED inicializálása[cite: 6]
  for (int i = 0; i < NUM_KEYS; i++) {
    pinMode(KEY_PINS[i], INPUT_PULLUP);
    pinMode(LED_PINS[i], OUTPUT);
    
    keyStates[i] = (digitalRead(KEY_PINS[i]) == LOW);
    lastKeyStates[i] = keyStates[i];
    suspendedStates[i] = false;
  }
  
  logEvent("Rendszer inicializálva. 6 kulcs figyelése elindult.");

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi csatlakoztatva. IP: " + WiFi.localIP().toString());

  server.on("/", HTTP_GET, []() {
    server.send(200, "text/html", index_html);
  });

  // REST API Státusz lekéréshez (JSON tömb generálása)
  server.on("/api/status", HTTP_GET, []() {
    String json = "{\"log\":\"" + eventLog + "\",\"keys\":[";
    for (int i = 0; i < NUM_KEYS; i++) {
      json += "{";
      json += "\"physical\":\"" + String(keyStates[i] ? "HELYÉN" : "ELVÉVE") + "\",";
      json += "\"suspended\":" + String(suspendedStates[i] ? "true" : "false");
      json += "}";
      if (i < NUM_KEYS - 1) json += ","; // Vessző az elemek közé
    }
    json += "]}";
    server.send(200, "application/json", json);
  });

  // Kulcs felfüggesztése végpont URL paraméterrel
  server.on("/api/suspend", HTTP_POST, []() {
    if (server.hasArg("id")) {
      int id = server.arg("id").toInt();
      if (id >= 0 && id < NUM_KEYS) {
        suspendedStates[id] = true;
        logEvent("Webes parancs: " + String(id + 1) + ". kulcs FELFÜGGESZTVE.");
      }
    }
    server.send(200, "text/plain", "OK");
  });

  // Kulcs újraaktiválása végpont URL paraméterrel
  server.on("/api/activate", HTTP_POST, []() {
    if (server.hasArg("id")) {
      int id = server.arg("id").toInt();
      if (id >= 0 && id < NUM_KEYS) {
        suspendedStates[id] = false;
        logEvent("Webes parancs: " + String(id + 1) + ". kulcs ÚJRAAKTIVÁLVA.");
      }
    }
    server.send(200, "text/plain", "OK");
  });

  server.begin();
}

void loop() {
  server.handleClient();

  // Fizikai állapotok folyamatos olvasása
  for (int i = 0; i < NUM_KEYS; i++) {
    keyStates[i] = (digitalRead(KEY_PINS[i]) == LOW); 
    
    // LED vezérlés
    digitalWrite(LED_PINS[i], keyStates[i] ? HIGH : LOW);

    // Eseményérzékelés minden kulcsra külön
    if (keyStates[i] != lastKeyStates[i]) {
      if (keyStates[i]) {
        logEvent("Esemény: " + String(i + 1) + ". kulcs VISSZAHELYEZVE a táblára.");
      } else {
        if (suspendedStates[i]) {
           logEvent("RIASZTÁS: Egy FELFÜGGESZTETT kulcsot (" + String(i + 1) + ".) vettek el!");
        } else {
           logEvent("Esemény: " + String(i + 1) + ". kulcs ELVÉVE.");
        }
      }
      lastKeyStates[i] = keyStates[i];
      delay(50); 
    }
  }
}